<?php
/**
 * Created by PhpStorm.
 * User: 08417523464
 * Date: 14/07/2016
 * Time: 15:29
 */

namespace App\Repositories\Exceptions;


class RepositoryException extends \Exception {

}