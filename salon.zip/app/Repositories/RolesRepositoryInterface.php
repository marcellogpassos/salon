<?php
/**
 * Created by PhpStorm.
 * User: asus
 * Date: 23/06/2016
 * Time: 08:27
 */

namespace App\Repositories;


interface RolesRepositoryInterface {

	public function getAll();

}