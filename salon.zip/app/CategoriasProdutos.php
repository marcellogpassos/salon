<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class CategoriasProdutos extends Model {

    protected $table = 'categorias_produtos';

}
