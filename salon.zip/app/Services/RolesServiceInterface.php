<?php
/**
 * Created by PhpStorm.
 * User: asus
 * Date: 23/06/2016
 * Time: 08:30
 */

namespace App\Services;


interface RolesServiceInterface {

	public function listarTodos();

}