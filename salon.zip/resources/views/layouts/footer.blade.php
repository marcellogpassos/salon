<footer class="page-footer">
    {{--<div class="container">--}}
    {{--<div class="row">--}}

    {{--</div>--}}
    {{--</div>--}}
    <div class="container center">
        <p><strong>Salon Project</strong>© Copyright 2016-2016 :: Marcello Galdino Passos</p>
    </div>
</footer>