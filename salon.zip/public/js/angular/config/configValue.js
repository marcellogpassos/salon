app.constant("config", {
    enderecosUrl: "http://enderecos.pe.hu",
    viaCepUrl: "https://viacep.com.br/ws/:cep/json/"
});