var app = angular.module('blank', [
    'ngResource'
]);